

<?php $__env->startSection('title', 'Menu'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <!-- Success Alert with dismissible option -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Enhanced Header with Search -->
    <div class="row mb-4 align-items-center">
        <div class="col-md-6">
            <h2>Our Menu</h2>
        </div>
        <div class="col-md-6">
            <div class="input-group">
                <input type="text" class="form-control" id="searchMenu" placeholder="Search menu items...">
                <button class="btn btn-outline-secondary" type="button">
                    <i class="bi bi-search"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Menu Items with Enhanced Cards -->
    <div class="row">
        <div class="col-md-3">
            <!-- Categories with Badge Showing Count -->
            <div class="list-group">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('menu.category', $category->id)); ?>" 
                   class="list-group-item d-flex justify-content-between align-items-center
                   <?php echo e(request('category') == $category->id ? 'active' : ''); ?>">
                    <?php echo e($category->name); ?>

                    <span class="badge bg-primary rounded-pill"><?php echo e($category->menus_count); ?></span>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-9">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        <?php if($menu->image): ?>
                        <img src="<?php echo e(asset('storage/' . $menu->image)); ?>" class="card-img-top" alt="<?php echo e($menu->name); ?>">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($menu->name); ?></h5>
                            <p class="card-text"><?php echo e($menu->description); ?></p>
                            <p class="card-text">
                                <span class="badge bg-info text-dark"><?php echo e($menu->category->name); ?></span>
                            </p>
                            <p class="card-text"><strong>Rp <?php echo e(number_format($menu->price, 0, ',', '.')); ?></strong></p>
                        </div>
                        <div class="card-footer bg-transparent border-top-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            data-bs-toggle="modal" data-bs-target="#editMenu<?php echo e($menu->id); ?>">
                                        Edit
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                            data-bs-toggle="modal" data-bs-target="#deleteMenu<?php echo e($menu->id); ?>">
                                        Delete
                                    </button>
                                </div>
                                <!-- Add this in your menu card -->
                                <button class="btn btn-primary add-to-cart" data-id="<?php echo e($menu->id); ?>">
                                    Add to Cart
                                </button>
                                
                                <?php $__env->startPush('scripts'); ?>
                                <script>
                                $(document).ready(function() {
                                    $('.add-to-cart').click(function(e) {
                                        e.preventDefault();
                                        var menuId = $(this).data('id');
                                        $.ajax({
                                            url: '/cart/add/' + menuId,
                                            method: 'POST',
                                            data: {
                                                _token: '<?php echo e(csrf_token()); ?>'
                                            },
                                            success: function(response) {
                                                // Update cart count in navbar
                                                $('#cartCount').text(response.cartCount);
                                                // Show success message
                                                alert('Item added to cart!');
                                            }
                                        });
                                    });
                                });
                                </script>
                                <?php $__env->stopPush(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- Pagination -->
            <div class="mt-4">
                <?php echo e($menus->links()); ?>

            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editMenu<?php echo e($menu->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Menu Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('menu.update', $menu)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <!-- Form fields here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\errrr php yes\htdocs\restosmk\resources\views\menu\index.blade.php ENDPATH**/ ?>