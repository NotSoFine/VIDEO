

<?php $__env->startSection('title', 'Edit Menu Item'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Edit Menu Item</h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <form action="<?php echo e(route('menu.update', $menu)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <?php echo $__env->make('menu.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <button type="submit" class="btn btn-primary">Update Menu Item</button>
                <a href="<?php echo e(route('menu')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\errrr php yes\htdocs\restosmk\resources\views\menu\edit.blade.php ENDPATH**/ ?>