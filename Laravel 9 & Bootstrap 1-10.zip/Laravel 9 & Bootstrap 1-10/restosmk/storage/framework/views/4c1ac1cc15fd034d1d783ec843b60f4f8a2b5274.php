

<?php $__env->startSection('title', 'Shopping Cart'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Shopping Cart</h2>
        </div>
    </div>

    <?php if(count($cart) > 0): ?>
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-id="<?php echo e($id); ?>">
                    <td>
                        <div class="d-flex align-items-center">
                            <?php if($details['image']): ?>
                            <img src="<?php echo e(asset('storage/' . $details['image'])); ?>" 
                                 alt="<?php echo e($details['name']); ?>" 
                                 class="img-thumbnail me-3" 
                                 style="width: 50px">
                            <?php endif; ?>
                            <span><?php echo e($details['name']); ?></span>
                        </div>
                    </td>
                    <td>Rp <?php echo e(number_format($details['price'], 0, ',', '.')); ?></td>
                    <td>
                        <input type="number" 
                               class="form-control quantity update-cart" 
                               value="<?php echo e($details['quantity']); ?>" 
                               min="1" 
                               style="width: 100px">
                    </td>
                    <td>Rp <?php echo e(number_format($details['price'] * $details['quantity'], 0, ',', '.')); ?></td>
                    <td>
                        <button class="btn btn-danger btn-sm remove-from-cart">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td colspan="2"><strong>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="row mt-4">
        <div class="col text-end">
            <a href="<?php echo e(route('menu')); ?>" class="btn btn-secondary">Continue Shopping</a>
            <a href="<?php echo e(route('orders.checkout')); ?>" class="btn btn-primary">Proceed to Checkout</a>
        </div>
    </div>
    <?php else: ?>
    <div class="alert alert-info">
        Your cart is empty! <a href="<?php echo e(route('menu')); ?>">Continue shopping</a>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('.update-cart').change(function(e) {
            e.preventDefault();
            var ele = $(this);
            $.ajax({
                url: '<?php echo e(route('cart.update')); ?>',
                method: "patch",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>', 
                    id: ele.parents("tr").attr("data-id"), 
                    quantity: ele.val()
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        });

        $('.remove-from-cart').click(function (e) {
            e.preventDefault();
            var ele = $(this);
            if(confirm("Are you sure you want to remove this item?")) {
                $.ajax({
                    url: '<?php echo e(route('cart.remove')); ?>',
                    method: "DELETE",
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>', 
                        id: ele.parents("tr").attr("data-id")
                    },
                    success: function (response) {
                        window.location.reload();
                    }
                });
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\errrr php yes\htdocs\restosmk\resources\views\orders\cart.blade.php ENDPATH**/ ?>