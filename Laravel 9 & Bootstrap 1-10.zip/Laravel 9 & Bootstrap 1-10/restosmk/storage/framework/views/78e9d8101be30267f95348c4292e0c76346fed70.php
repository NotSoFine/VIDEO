

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
    <h1 class="display-4">Welcome to RestoSMK</h1>
    <p class="lead">Your favorite restaurant management system</p>
    <hr class="my-4">
    <p>Start by browsing our menu or managing orders</p>
    <a class="btn btn-primary btn-lg" href="<?php echo e(route('menu')); ?>" role="button">View Menu</a>
    <a class="btn btn-secondary btn-lg" href="<?php echo e(route('orders')); ?>" role="button">Manage Orders</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 text-center mb-4">
            <h1><?php echo e($welcomeMessage); ?></h1>
        </div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($category['name']); ?></h5>
                        <a href="<?php echo e(route('menu.category', $category['id'])); ?>" class="btn btn-primary">View Menu</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Documents\errrr php yes\htdocs\restosmk\resources\views/home.blade.php ENDPATH**/ ?>