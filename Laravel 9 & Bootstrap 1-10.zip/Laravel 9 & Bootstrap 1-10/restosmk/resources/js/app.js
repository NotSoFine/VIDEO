require('./bootstrap');

// Real-time order updates using Laravel Echo
Echo.private('orders')
    .listen('OrderStatusChanged', (e) => {
        updateOrderStatus(e.order);
    });

axios.interceptors.request.use(config => {
    // Show loading indicator
    document.body.classList.add('loading');
    return config;
}, error => {
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred. Please try again.');
    return Promise.reject(error);
});

axios.interceptors.response.use(response => {
    // Hide loading indicator
    document.body.classList.remove('loading');
    return response;
}, error => {
    // Hide loading indicator and show error message
    document.body.classList.remove('loading');
    alert('An error occurred