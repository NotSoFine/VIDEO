@extends('layouts.app')

@section('content')
<div class="container-fluid py-4">
    <div class="row g-4">
        <!-- Statistics Cards -->
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Total Orders</h5>
                    <h2 class="mb-0">{{ $totalOrders }}</h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h5 class="card-title">Today's Orders</h5>
                    <h2 class="mb-0">{{ $todayOrders }}</h2>
                </div>
            </div>
        </div>
        
        <!-- Popular Items Chart -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Popular Items</h5>
                    <canvas id="popularItemsChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Revenue Chart -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Revenue Trend</h5>
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Initialize charts with the data from the controller
    const popularItemsChart = new Chart(
        document.getElementById('popularItemsChart'),
        {
            type: 'bar',
            data: {
                labels: {!! json_encode($popularItems->pluck('menu.name')) !!},
                datasets: [{
                    label: 'Orders',
                    data: {!! json_encode($popularItems->pluck('total')) !!}
                }]
            }
        }
    );
    
    const revenueChart = new Chart(
        document.getElementById('revenueChart'),
        {
            type: 'line',
            data: {
                labels: {!! json_encode($revenueData->pluck('date')) !!},
                datasets: [{
                    label: 'Daily Revenue',
                    data: {!! json_encode($revenueData->pluck('revenue')) !!}
                }]
            }
        }
    );
</script>
@endpush
@endsection