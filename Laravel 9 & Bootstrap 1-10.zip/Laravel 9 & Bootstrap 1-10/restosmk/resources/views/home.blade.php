@extends('layouts.app')

@section('title', 'Home')

@section('content')
<div class="jumbotron text-center">
    <h1 class="display-4">Welcome to RestoSMK</h1>
    <p class="lead">Your favorite restaurant management system</p>
    <hr class="my-4">
    <p>Start by browsing our menu or managing orders</p>
    <a class="btn btn-primary btn-lg" href="{{ route('menu') }}" role="button">View Menu</a>
    <a class="btn btn-secondary btn-lg" href="{{ route('orders') }}" role="button">Manage Orders</a>
</div>
@endsection
@section('content')
    <div class="row">
        <div class="col-12 text-center mb-4">
            <h1>{{ $welcomeMessage }}</h1>
        </div>
    </div>

    <div class="row">
        @foreach($featuredCategories as $category)
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">{{ $category['name'] }}</h5>
                        <a href="{{ route('menu.category', $category['id']) }}" class="btn btn-primary">View Menu</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection