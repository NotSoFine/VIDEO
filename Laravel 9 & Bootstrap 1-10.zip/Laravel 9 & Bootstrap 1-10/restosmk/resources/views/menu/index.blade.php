@extends('layouts.app')

@section('title', 'Menu')

@section('content')
<div class="container">
    <!-- Success Alert with dismissible option -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Enhanced Header with Search -->
    <div class="row mb-4 align-items-center">
        <div class="col-md-6">
            <h2>Our Menu</h2>
        </div>
        <div class="col-md-6">
            <div class="input-group">
                <input type="text" class="form-control" id="searchMenu" placeholder="Search menu items...">
                <button class="btn btn-outline-secondary" type="button">
                    <i class="bi bi-search"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Menu Items with Enhanced Cards -->
    <div class="row">
        <div class="col-md-3">
            <!-- Categories with Badge Showing Count -->
            <div class="list-group">
                @foreach($categories as $category)
                <a href="{{ route('menu.category', $category->id) }}" 
                   class="list-group-item d-flex justify-content-between align-items-center
                   {{ request('category') == $category->id ? 'active' : '' }}">
                    {{ $category->name }}
                    <span class="badge bg-primary rounded-pill">{{ $category->menus_count }}</span>
                </a>
                @endforeach
            </div>
        </div>
        <div class="col-md-9">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                @foreach($menus as $menu)
                <div class="col">
                    <div class="card h-100 shadow-sm">
                        @if($menu->image)
                        <img src="{{ asset('storage/' . $menu->image) }}" class="card-img-top" alt="{{ $menu->name }}">
                        @endif
                        <div class="card-body">
                            <h5 class="card-title">{{ $menu->name }}</h5>
                            <p class="card-text">{{ $menu->description }}</p>
                            <p class="card-text">
                                <span class="badge bg-info text-dark">{{ $menu->category->name }}</span>
                            </p>
                            <p class="card-text"><strong>Rp {{ number_format($menu->price, 0, ',', '.') }}</strong></p>
                        </div>
                        <div class="card-footer bg-transparent border-top-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            data-bs-toggle="modal" data-bs-target="#editMenu{{ $menu->id }}">
                                        Edit
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                            data-bs-toggle="modal" data-bs-target="#deleteMenu{{ $menu->id }}">
                                        Delete
                                    </button>
                                </div>
                                <!-- Add this in your menu card -->
                                <button class="btn btn-primary add-to-cart" data-id="{{ $menu->id }}">
                                    Add to Cart
                                </button>
                                
                                @push('scripts')
                                <script>
                                $(document).ready(function() {
                                    $('.add-to-cart').click(function(e) {
                                        e.preventDefault();
                                        var menuId = $(this).data('id');
                                        $.ajax({
                                            url: '/cart/add/' + menuId,
                                            method: 'POST',
                                            data: {
                                                _token: '{{ csrf_token() }}'
                                            },
                                            success: function(response) {
                                                // Update cart count in navbar
                                                $('#cartCount').text(response.cartCount);
                                                // Show success message
                                                alert('Item added to cart!');
                                            }
                                        });
                                    });
                                });
                                </script>
                                @endpush
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <!-- Pagination -->
            <div class="mt-4">
                {{ $menus->links() }}
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
@foreach($menus as $menu)
<div class="modal fade" id="editMenu{{ $menu->id }}" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Menu Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="{{ route('menu.update', $menu) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <!-- Form fields here -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endforeach
@endsection