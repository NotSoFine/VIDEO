@extends('layouts.app')

@section('title', 'Edit Menu Item')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Edit Menu Item</h2>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <form action="{{ route('menu.update', $menu) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                @include('menu.form')
                
                <button type="submit" class="btn btn-primary">Update Menu Item</button>
                <a href="{{ route('menu') }}" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection