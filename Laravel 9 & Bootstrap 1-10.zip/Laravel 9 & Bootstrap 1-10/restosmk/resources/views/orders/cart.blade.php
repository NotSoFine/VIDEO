@extends('layouts.app')

@section('title', 'Shopping Cart')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col">
            <h2>Shopping Cart</h2>
        </div>
    </div>

    @if(count($cart) > 0)
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($cart as $id => $details)
                <tr data-id="{{ $id }}">
                    <td>
                        <div class="d-flex align-items-center">
                            @if($details['image'])
                            <img src="{{ asset('storage/' . $details['image']) }}" 
                                 alt="{{ $details['name'] }}" 
                                 class="img-thumbnail me-3" 
                                 style="width: 50px">
                            @endif
                            <span>{{ $details['name'] }}</span>
                        </div>
                    </td>
                    <td>Rp {{ number_format($details['price'], 0, ',', '.') }}</td>
                    <td>
                        <input type="number" 
                               class="form-control quantity update-cart" 
                               value="{{ $details['quantity'] }}" 
                               min="1" 
                               style="width: 100px">
                    </td>
                    <td>Rp {{ number_format($details['price'] * $details['quantity'], 0, ',', '.') }}</td>
                    <td>
                        <button class="btn btn-danger btn-sm remove-from-cart">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                    <td colspan="2"><strong>Rp {{ number_format($total, 0, ',', '.') }}</strong></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="row mt-4">
        <div class="col text-end">
            <a href="{{ route('menu') }}" class="btn btn-secondary">Continue Shopping</a>
            <a href="{{ route('orders.checkout') }}" class="btn btn-primary">Proceed to Checkout</a>
        </div>
    </div>
    @else
    <div class="alert alert-info">
        Your cart is empty! <a href="{{ route('menu') }}">Continue shopping</a>
    </div>
    @endif
</div>

@push('scripts')
<script>
    $(document).ready(function() {
        $('.update-cart').change(function(e) {
            e.preventDefault();
            var ele = $(this);
            $.ajax({
                url: '{{ route('cart.update') }}',
                method: "patch",
                data: {
                    _token: '{{ csrf_token() }}', 
                    id: ele.parents("tr").attr("data-id"), 
                    quantity: ele.val()
                },
                success: function (response) {
                    window.location.reload();
                }
            });
        });

        $('.remove-from-cart').click(function (e) {
            e.preventDefault();
            var ele = $(this);
            if(confirm("Are you sure you want to remove this item?")) {
                $.ajax({
                    url: '{{ route('cart.remove') }}',
                    method: "DELETE",
                    data: {
                        _token: '{{ csrf_token() }}', 
                        id: ele.parents("tr").attr("data-id")
                    },
                    success: function (response) {
                        window.location.reload();
                    }
                });
            }
        });
    });
</script>
@endpush
@endsection