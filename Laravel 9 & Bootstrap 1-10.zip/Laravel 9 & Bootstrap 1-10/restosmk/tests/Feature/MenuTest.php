<?php

namespace Tests\Feature;

use App\Models\Menu;
use App\Models\Category;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

class MenuTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        Storage::fake('public');
    }

    public function test_menu_index_page_can_be_rendered()
    {
        $response = $this->get('/menu');
        $response->assertStatus(200);
    }

    public function test_menu_can_be_created()
    {
        $user = User::factory()->create();
        $category = Category::factory()->create();
        
        $response = $this->actingAs($user)->post('/menu', [
            'name' => 'Test Menu',
            'description' => 'Test Description',
            'price' => 10000,
            'category_id' => $category->id,
            'image' => UploadedFile::fake()->image('menu.jpg')
        ]);

        $this->assertDatabaseHas('menus', [
            'name' => 'Test Menu',
            'description' => 'Test Description',
            'price' => 10000,
            'category_id' => $category->id
        ]);
    }
}