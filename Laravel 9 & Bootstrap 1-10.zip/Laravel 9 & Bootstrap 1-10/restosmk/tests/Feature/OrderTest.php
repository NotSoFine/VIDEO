<?php

namespace Tests\Feature;

use App\Models\Order;
use App\Models\Menu;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OrderTest extends TestCase
{
    use RefreshDatabase;

    public function test_order_can_be_created()
    {
        $user = User::factory()->create();
        $menu = Menu::factory()->create(['price' => 10000]);

        $response = $this->actingAs($user)->post('/cart/add/' . $menu->id);
        $response->assertStatus(200);

        $response = $this->post('/checkout', [
            'table_number' => '1',
            'notes' => 'Test Order'
        ]);

        $this->assertDatabaseHas('orders', [
            'user_id' => $user->id,
            'table_number' => '1',
            'notes' => 'Test Order',
            'status' => 'pending'
        ]);
    }
}