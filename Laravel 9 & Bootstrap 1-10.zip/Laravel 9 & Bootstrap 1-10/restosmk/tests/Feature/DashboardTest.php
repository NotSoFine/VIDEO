<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Order;
use Illuminate\Foundation\Testing\RefreshDatabase;

class DashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_dashboard_displays_correct_statistics()
    {
        $user = User::factory()->create();
        $this->actingAs($user);

        // Create some test orders
        Order::factory()->count(5)->create();

        $response = $this->get('/dashboard');

        $response->assertStatus(200)
                 ->assertViewHas('totalOrders')
                 ->assertViewHas('todayOrders')
                 ->assertViewHas('popularItems')
                 ->assertViewHas('revenueData');
    }
}