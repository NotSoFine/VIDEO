<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreOrderRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'table_number' => 'required|string|max:10',
            'notes' => 'nullable|string|max:500',
        ];
    }

    public function messages()
    {
        return [
            'table_number.required' => 'Please enter a table number',
            'table_number.max' => 'Table number cannot exceed 10 characters',
            'notes.max' => 'Notes cannot exceed 500 characters',
        ];
    }
}