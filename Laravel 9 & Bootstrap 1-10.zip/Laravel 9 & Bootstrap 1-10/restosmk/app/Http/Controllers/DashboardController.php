<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Menu;
use App\Models\OrderDetail;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $totalOrders = Order::count();
        $todayOrders = Order::whereDate('created_at', Carbon::today())->count();
        
        $popularItems = OrderDetail::select('menu_id', DB::raw('count(*) as total'))
            ->groupBy('menu_id')
            ->orderByDesc('total')
            ->limit(5)
            ->with('menu')
            ->get();
            
        $revenueData = Order::select(
            DB::raw('DATE(created_at) as date'),
            DB::raw('SUM(total_amount) as revenue')
        )
            ->groupBy('date')
            ->orderBy('date')
            ->get();
            
        return view('dashboard.index', compact(
            'totalOrders', 
            'todayOrders', 
            'popularItems',
            'revenueData'
        ));
    }
}