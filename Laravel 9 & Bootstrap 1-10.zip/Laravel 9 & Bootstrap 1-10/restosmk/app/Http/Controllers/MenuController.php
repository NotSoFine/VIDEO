<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class MenuController extends Controller
{
    public function index(Request $request)
    {
        $query = Menu::with(['category']); // Eager loading

        // Search functionality
        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
        }

        // Category filter
        if ($request->has('category')) {
            $query->where('category_id', $request->category);
        }

        // Price sorting
        if ($request->has('sort')) {
            $sort = $request->get('sort');
            if ($sort === 'price_asc') {
                $query->orderBy('price', 'asc');
            } elseif ($sort === 'price_desc') {
                $query->orderBy('price', 'desc');
            }
        }

        $categories = Category::withCount('menus')->get();
        $menus = $query->paginate(15);

        return view('menu.index', compact('categories', 'menus'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('menu.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'category_id' => 'required|exists:categories,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $menu = new Menu($validated);

        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('public/menu');
            $menu->image = Storage::url($path);
        }

        $menu->save();

        return redirect()->route('menu.index')
            ->with('success', 'Menu item created successfully!');
    }

    public function edit(Menu $menu)
    {
        $categories = Category::all();
        return view('menu.edit', compact('menu', 'categories'));
    }

    public function update(Request $request, Menu $menu)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'category_id' => 'required|exists:categories,id',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        if ($request->hasFile('image')) {
            // Delete old image
            if ($menu->image) {
                Storage::delete(str_replace('/storage', 'public', $menu->image));
            }
            $path = $request->file('image')->store('public/menu');
            $validated['image'] = Storage::url($path);
        }

        $menu->update($validated);

        return redirect()->route('menu.index')
            ->with('success', 'Menu item updated successfully!');
    }

    public function destroy(Menu $menu)
    {
        if ($menu->image) {
            Storage::delete(str_replace('/storage', 'public', $menu->image));
        }
        $menu->delete();

        return redirect()->route('menu.index')
            ->with('success', 'Menu item deleted successfully!');
    }
}