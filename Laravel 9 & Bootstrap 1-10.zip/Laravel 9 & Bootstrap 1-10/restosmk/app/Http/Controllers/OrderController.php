<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with(['user', 'orderDetails.menu'])
                       ->latest()
                       ->paginate(15);
        return view('orders.index', compact('orders'));
    }

    public function kitchen()
    {
        $activeOrders = cache()->remember('active_orders', 60, function () {
            return Order::whereIn('status', ['pending', 'preparing'])
                ->with(['orderDetails.menu', 'user'])
                ->orderBy('created_at', 'asc')
                ->get();
        });

        return view('orders.kitchen', compact('activeOrders'));
    }

    public function addToCart($menuId)
    {
        $menu = Menu::findOrFail($menuId);
        $cart = Session::get('cart', []);

        if (isset($cart[$menuId])) {
            $cart[$menuId]['quantity']++;
        } else {
            $cart[$menuId] = [
                'name' => $menu->name,
                'price' => $menu->price,
                'quantity' => 1,
                'image' => $menu->image
            ];
        }

        Session::put('cart', $cart);
        return redirect()->back()->with('success', 'Item added to cart!');
    }
}