<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;

class RolesAndPermissionsSeeder extends Seeder
{
    public function run()
    {
        // Create roles
        $adminRole = Role::create(['name' => 'admin', 'description' => 'Administrator']);
        $staffRole = Role::create(['name' => 'staff', 'description' => 'Staff Member']);
        $customerRole = Role::create(['name' => 'customer', 'description' => 'Customer']);

        // Create permissions
        $manageUsers = Permission::create(['name' => 'manage-users', 'description' => 'Can manage users']);
        $manageMenu = Permission::create(['name' => 'manage-menu', 'description' => 'Can manage menu items']);
        $manageOrders = Permission::create(['name' => 'manage-orders', 'description' => 'Can manage orders']);
        $viewOrders = Permission::create(['name' => 'view-orders', 'description' => 'Can view orders']);
        $placeOrders = Permission::create(['name' => 'place-orders', 'description' => 'Can place orders']);

        // Assign permissions to roles
        $adminRole->permissions()->attach([
            $manageUsers->id,
            $manageMenu->id,
            $manageOrders->id,
            $viewOrders->id,
            $placeOrders->id
        ]);

        $staffRole->permissions()->attach([
            $manageMenu->id,
            $manageOrders->id,
            $viewOrders->id
        ]);

        $customerRole->permissions()->attach([
            $placeOrders->id
        ]);
    }
}