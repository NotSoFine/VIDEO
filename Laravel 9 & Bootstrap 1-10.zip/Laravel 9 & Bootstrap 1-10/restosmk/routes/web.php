<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DashboardController;

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/menu', [MenuController::class, 'index'])->name('menu.index');
Route::get('/menu/category/{category}', [MenuController::class, 'category'])->name('menu.category');

// Authentication routes
Auth::routes();

// Customer routes
Route::middleware(['auth', 'role:customer'])->group(function () {
    Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
    Route::post('/cart/add/{menu}', [OrderController::class, 'addToCart'])->name('cart.add');
    Route::get('/cart', [OrderController::class, 'cart'])->name('cart.index');
    Route::post('/cart/clear', [OrderController::class, 'clearCart'])->name('cart.clear');
    Route::post('/checkout', [OrderController::class, 'checkout'])->name('checkout');
});

// Staff routes
Route::middleware(['auth', 'role:staff'])->group(function () {
    Route::get('/kitchen', [OrderController::class, 'kitchen'])->name('kitchen');
    Route::put('/orders/{order}/status', [OrderController::class, 'updateStatus'])->name('orders.status.update');
});

// Admin routes
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('menu', MenuController::class)->except(['index', 'show']);
    Route::resource('users', UserController::class);
    Route::get('/orders/reports', [OrderController::class, 'reports'])->name('orders.reports');
});

// Common authenticated routes
Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [UserController::class, 'profile'])->name('profile');
    Route::put('/profile', [UserController::class, 'updateProfile'])->name('profile.update');
});